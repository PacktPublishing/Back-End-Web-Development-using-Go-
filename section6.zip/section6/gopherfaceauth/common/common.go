package common

import "github.com/EngineerKamesh/gofullstack/volume2/section6/gopherfaceauth/common/datastore"

type Env struct {
	DB datastore.Datastore
}
